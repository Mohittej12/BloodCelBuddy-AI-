package com.example.bloodcelbuddy;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class AiImageAnalysisActivity extends AppCompatActivity {
    private static final String TAG = "AiImageAnalysis";

    TextView tvTitle, tvTestingId, tvSummary, tvImageCount;
    Button btnGenerateReport, btnManualCounter, btnAddMore;
    Spinner spinnerUpload;

    ArrayList<Uri> imageUris = new ArrayList<>();
    String testingId;
    JSONObject lastAnalysisResult = null;

    // Use your PC LAN IP when testing on a real device
    private final String CONFIGURED_BASE_URL = "http://172.25.57.155:5000";

    private ActivityResultLauncher<String[]> pickImagesLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ai_image_analysis);

        tvTitle = findViewById(R.id.tvTitle);
        tvTestingId = findViewById(R.id.tvTestingId);
        tvSummary = findViewById(R.id.tvSummary);
        spinnerUpload = findViewById(R.id.spinnerUpload);
        btnGenerateReport = findViewById(R.id.btnGenerateReport);
        btnManualCounter = findViewById(R.id.btnManualCounter);
        tvImageCount = findViewById(R.id.tvImageCount);
        btnAddMore = findViewById(R.id.btnAddMore);

        tvTitle.setText("AI Image Analysis");
        testingId = "TID-" + UUID.randomUUID().toString().substring(0,8);
        tvTestingId.setText("Testing ID: " + testingId);
        tvSummary.setText("No analysis yet.");

        updateImageCount();

        // ActivityResult launcher for SAF multiple selection (API 36 friendly)
        pickImagesLauncher = registerForActivityResult(
                new ActivityResultContracts.OpenMultipleDocuments(),
                new ActivityResultCallback<List<Uri>>() {
                    @Override
                    public void onActivityResult(List<Uri> result) {
                        if (result == null || result.isEmpty()) {
                            Log.d(TAG, "No images selected");
                            return;
                        }
                        // Add selected URIs to imageUris
                        for (Uri u : result) {
                            try {
                                final int takeFlags = Intent.FLAG_GRANT_READ_URI_PERMISSION;
                                getContentResolver().takePersistableUriPermission(u, takeFlags);
                            } catch (Exception e) {
                                Log.w(TAG, "Failed to persist URI permission: " + e.getMessage());
                            }
                            imageUris.add(u);
                            Log.d(TAG, "Added image URI: " + u.toString());
                        }
                        updateImageCount();

                        // If more than one selected, run a batch analysis and show aggregated total
                        if (result.size() > 1) {
                            Log.d(TAG, "Starting batch analysis for " + result.size() + " images.");
                            Uri[] urisArr = result.toArray(new Uri[0]);
                            lastAnalysisResult = null;
                            new AnalyzeBatchTask().execute(urisArr);
                        } else {
                            // single image selected -> analyze single (keeps older behavior)
                            Uri latest = result.get(0);
                            analyzeUriAndShow(latest);
                        }
                    }
                }
        );

        String[] uploadOptions = {"Select Images", "Add from Gallery / Files"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, uploadOptions);
        spinnerUpload.setAdapter(adapter);
        spinnerUpload.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> parent, android.view.View view, int position, long id) {
                String choice = uploadOptions[position];
                if (choice.equals("Add from Gallery / Files")) {
                    pickImagesLauncher.launch(new String[] {"image/*"});
                }
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) {}
        });

        btnAddMore.setOnClickListener(v -> pickImagesLauncher.launch(new String[] {"image/*"}));

        btnGenerateReport.setOnClickListener(v -> {
            if (lastAnalysisResult == null) {
                Toast.makeText(this, "Please analyze images first", Toast.LENGTH_SHORT).show();
                return;
            }
            new SaveAnalysisTask().execute(lastAnalysisResult.toString());
        });

        btnManualCounter.setOnClickListener(v -> finish());
    }

    private void updateImageCount() {
        tvImageCount.setText("Uploaded Images: " + imageUris.size());
    }

    private String getBaseUrl() {
        if (isEmulator()) return "http://10.0.2.2:5000";
        return CONFIGURED_BASE_URL;
    }

    private boolean isEmulator() {
        String fingerprint = android.os.Build.FINGERPRINT != null ? android.os.Build.FINGERPRINT : "";
        String model = android.os.Build.MODEL != null ? android.os.Build.MODEL : "";
        String product = android.os.Build.PRODUCT != null ? android.os.Build.PRODUCT : "";
        return fingerprint.startsWith("generic") || fingerprint.toLowerCase().contains("vbox")
                || model.contains("Emulator") || model.contains("Android SDK built for x86")
                || product.contains("sdk");
    }

    // Helper to force analyze a URI (clears cache and triggers task)
    private void analyzeUriAndShow(Uri uri) {
        lastAnalysisResult = null; // clear cached result
        Log.d(TAG, "Analyzing URI (force): " + uri);
        new AnalyzeTask().execute(uri);
    }

    // =========================================================
    // AnalyzeBatchTask - uploads multiple images sequentially,
    // accumulates counts and returns a single aggregated result.
    // =========================================================
    private class AnalyzeBatchTask extends AsyncTask<Uri, Void, String> {
        @Override
        protected void onPreExecute() {
            tvSummary.setText("Starting batch analysis...");
        }

        @Override
        protected String doInBackground(Uri... uris) {
            // Aggregate counts for these standard types
            Map<String, Integer> totalCounts = new HashMap<>();
            totalCounts.put("Neutrophils", 0);
            totalCounts.put("Lymphocytes", 0);
            totalCounts.put("Monocytes", 0);
            totalCounts.put("Eosinophils", 0);
            totalCounts.put("Basophils", 0);

            int succeeded = 0;
            int failed = 0;

            for (int i = 0; i < uris.length; i++) {
                Uri u = uris[i];
                final int index = i;
                try {
                    // Update UI progress via logs and tvSummary (can't update UI in background thread,
                    // so accumulate a small progress string and return it; we'll also log)
                    Log.d(TAG, "Batch: analyzing image " + (index+1) + " / " + uris.length + " -> " + u);

                    // Reuse the same upload logic used in AnalyzeTask
                    HttpURLConnection conn = null;
                    DataOutputStream dos = null;
                    try {
                        InputStream inputStream = getContentResolver().openInputStream(u);
                        if (inputStream == null) {
                            Log.e(TAG, "Batch: cannot open URI " + u);
                            failed++;
                            continue;
                        }
                        BufferedInputStream bis = new BufferedInputStream(inputStream);
                        ByteArrayOutputStream baos = new ByteArrayOutputStream();
                        byte[] buffer = new byte[4096];
                        int bytesRead;
                        while ((bytesRead = bis.read(buffer)) != -1) {
                            baos.write(buffer, 0, bytesRead);
                        }
                        bis.close();
                        byte[] fileBytes = baos.toByteArray();

                        // derive filename
                        String fileName = "image.jpg";
                        try (Cursor cursor = getContentResolver().query(u, null, null, null, null)) {
                            if (cursor != null && cursor.moveToFirst()) {
                                int idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                                if (idx != -1) fileName = cursor.getString(idx);
                            }
                        } catch (Exception e) {
                            Log.w(TAG, "Batch: failed to read display name: " + e.getMessage());
                        }

                        String mimeType = getContentResolver().getType(u);
                        if (mimeType == null) mimeType = "image/jpeg";

                        String boundary = "----WebKitFormBoundary" + System.currentTimeMillis();
                        String urlStr = getBaseUrl() + "/analyze?t=" + System.currentTimeMillis();
                        URL url = new URL(urlStr);
                        conn = (HttpURLConnection) url.openConnection();
                        conn.setRequestMethod("POST");
                        conn.setConnectTimeout(30000);
                        conn.setReadTimeout(60000);
                        conn.setDoOutput(true);

                        conn.setUseCaches(false);
                        conn.setRequestProperty("Cache-Control", "no-cache, no-store, must-revalidate");
                        conn.setRequestProperty("Pragma", "no-cache");
                        conn.setRequestProperty("Expires", "0");

                        conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
                        conn.setRequestProperty("Connection", "Keep-Alive");
                        conn.setRequestProperty("Accept", "application/json");

                        dos = new DataOutputStream(conn.getOutputStream());
                        dos.writeBytes("--" + boundary + "\r\n");
                        dos.writeBytes("Content-Disposition: form-data; name=\"image\"; filename=\"" + fileName + "\"\r\n");
                        dos.writeBytes("Content-Type: " + mimeType + "\r\n\r\n");
                        dos.write(fileBytes);
                        dos.writeBytes("\r\n--" + boundary + "--\r\n");
                        dos.flush();

                        int rc = conn.getResponseCode();
                        Log.d(TAG, "Batch /analyze #" + (index+1) + " response code: " + rc);

                        InputStream responseStream = (rc >= 400) ? conn.getErrorStream() : conn.getInputStream();
                        if (responseStream == null) {
                            Log.e(TAG, "Batch: no response stream for image " + (index+1));
                            failed++;
                            continue;
                        }

                        BufferedReader br = new BufferedReader(new InputStreamReader(responseStream, StandardCharsets.UTF_8));
                        StringBuilder sb = new StringBuilder();
                        String line;
                        while ((line = br.readLine()) != null) sb.append(line);
                        br.close();
                        String resp = sb.toString();
                        Log.d(TAG, "Batch /analyze #" + (index+1) + " body: " + (resp.length() > 800 ? resp.substring(0,800) + "..." : resp));

                        // Parse the response and extract counts
                        JSONObject json = new JSONObject(resp);
                        if (json.has("error")) {
                            Log.e(TAG, "Batch: /analyze reported error for image " + (index+1) + ": " + json.optString("error"));
                            failed++;
                            continue;
                        }
                        if (!json.has("result")) {
                            Log.e(TAG, "Batch: /analyze missing 'result' for image " + (index+1));
                            failed++;
                            continue;
                        }

                        JSONObject resultObj = json.getJSONObject("result");
                        JSONArray wbcArray = resultObj.getJSONArray("wbc_types");

                        // Add counts to totalCounts
                        for (int j = 0; j < wbcArray.length(); j++) {
                            JSONObject cell = wbcArray.getJSONObject(j);
                            String type = cell.getString("type");
                            int count = cell.getInt("count");
                            // ensure canonical capitalization keys
                            String key = canonicalKey(type);
                            int prev = totalCounts.containsKey(key) ? totalCounts.get(key) : 0;
                            totalCounts.put(key, prev + count);
                        }

                        succeeded++;
                    } catch (Exception innerEx) {
                        Log.e(TAG, "Batch: exception analyzing image " + (index+1) + ": " + innerEx.getMessage(), innerEx);
                        failed++;
                    } finally {
                        try { if (dos != null) dos.close(); } catch (Exception ignored) {}
                        if (conn != null) conn.disconnect();
                    }

                    // small pause optional (not necessary)
                    // Thread.sleep(50);
                } catch (Exception outerEx) {
                    Log.e(TAG, "Batch: outer exception processing URI: " + outerEx.getMessage(), outerEx);
                    failed++;
                }
            } // end for

            // After processing all images, build aggregated JSON result
            int grandTotal = 0;
            for (String k : totalCounts.keySet()) grandTotal += totalCounts.get(k);

            JSONArray aggregated = new JSONArray();
            String[] expected = new String[] {"Neutrophils","Lymphocytes","Monocytes","Eosinophils","Basophils"};
            for (String name : expected) {
                int cnt = totalCounts.containsKey(name) ? totalCounts.get(name) : 0;
                double pct = grandTotal > 0 ? (cnt * 100.0 / grandTotal) : 0.0;
                JSONObject obj = new JSONObject();
                try {
                    obj.put("type", name);
                    obj.put("count", cnt);
                    obj.put("percentage", Math.round(pct * 100.0) / 100.0); // round to 2 decimals
                } catch (Exception e) {
                    Log.w(TAG, "Failed to build aggregated object for " + name, e);
                }
                aggregated.put(obj);
            }

            JSONObject top = new JSONObject();
            try {
                JSONObject res = new JSONObject();
                res.put("wbc_types", aggregated);
                top.put("result", res);
                JSONObject meta = new JSONObject();
                meta.put("images_processed", uris.length);
                meta.put("images_succeeded", succeeded);
                meta.put("images_failed", failed);
                meta.put("total_cells", grandTotal);
                top.put("debug_meta", meta);
            } catch (Exception e) {
                Log.e(TAG, "Failed to build aggregated top-level JSON", e);
                // fallback: return error JSON
                return "{\"error\":\"Aggregation failed: " + e.getMessage().replace("\"","'") + "\"}";
            }

            return top.toString();
        }

        @Override
        protected void onPostExecute(String result) {
            try {
                JSONObject json = new JSONObject(result);
                if (json.has("error")) {
                    String err = json.optString("error");
                    Log.e(TAG, "Batch analysis returned error: " + err);
                    tvSummary.setText("Batch analysis failed: " + err);
                    Toast.makeText(AiImageAnalysisActivity.this, "Batch analysis failed: " + err, Toast.LENGTH_LONG).show();
                    return;
                }

                // set lastAnalysisResult so SaveAnalysisTask uses aggregated totals
                lastAnalysisResult = json;

                JSONObject resultObj = json.getJSONObject("result");
                JSONArray wbcArray = resultObj.getJSONArray("wbc_types");

                JSONObject meta = json.optJSONObject("debug_meta");
                int imagesProcessed = meta != null ? meta.optInt("images_processed", 0) : 0;
                int imagesSucceeded = meta != null ? meta.optInt("images_succeeded", 0) : 0;
                int imagesFailed = meta != null ? meta.optInt("images_failed", 0) : 0;
                int totalCells = meta != null ? meta.optInt("total_cells", 0) : 0;

                StringBuilder summaryText = new StringBuilder();
                summaryText.append("Batch Summary (").append(imagesSucceeded).append("/").append(imagesProcessed).append(" succeeded");
                if (imagesFailed > 0) summaryText.append(", ").append(imagesFailed).append(" failed");
                summaryText.append(")\n\n");

                for (int i = 0; i < wbcArray.length(); i++) {
                    JSONObject cell = wbcArray.getJSONObject(i);
                    String type = cell.getString("type");
                    int count = cell.getInt("count");
                    double percentage = cell.getDouble("percentage");
                    summaryText.append(type).append(": ").append(count)
                            .append(" (").append(String.format("%.2f", percentage)).append("%)\n");
                }
                summaryText.append("\nTotal cells across images: ").append(totalCells);
                tvSummary.setText(summaryText.toString());

                Log.i(TAG, "Batch analysis complete. " + imagesSucceeded + "/" + imagesProcessed + " succeeded, " + imagesFailed + " failed.");
            } catch (Exception e) {
                Log.e(TAG, "Failed to parse batch analysis result: " + e.getMessage(), e);
                tvSummary.setText("Batch parsing error: " + e.getMessage());
                Toast.makeText(AiImageAnalysisActivity.this, "Batch parsing error: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }
    }

    // canonicalize type strings to expected labels
    private String canonicalKey(String raw) {
        if (raw == null) return "Unknown";
        String r = raw.trim().toLowerCase();
        if (r.contains("neut")) return "Neutrophils";
        if (r.contains("lymph")) return "Lymphocytes";
        if (r.contains("mono")) return "Monocytes";
        if (r.contains("eos")) return "Eosinophils";
        if (r.contains("baso")) return "Basophils";
        // fallback - capitalize first letter
        return raw.substring(0,1).toUpperCase() + raw.substring(1);
    }

    // Single-image AnalyzeTask (keeps previous behavior for single selection)
    private class AnalyzeTask extends AsyncTask<Uri, Void, String> {
        @Override
        protected void onPreExecute() {
            tvSummary.setText("Analyzing... please wait");
        }

        @Override
        protected String doInBackground(Uri... uris) {
            HttpURLConnection conn = null;
            DataOutputStream dos = null;
            try {
                Uri imageUri = uris[0];
                InputStream inputStream = getContentResolver().openInputStream(imageUri);
                if (inputStream == null) {
                    Log.e(TAG, "InputStream for URI is null: " + imageUri);
                    return "{\"error\":\"Cannot open image input stream\"}";
                }
                BufferedInputStream bis = new BufferedInputStream(inputStream);
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                byte[] buffer = new byte[4096];
                int bytesRead;
                while ((bytesRead = bis.read(buffer)) != -1) {
                    baos.write(buffer, 0, bytesRead);
                }
                bis.close();
                byte[] fileBytes = baos.toByteArray();
                Log.d(TAG, "Read image bytes: " + fileBytes.length);

                // derive filename (optional)
                String fileName = "image.jpg";
                try (Cursor cursor = getContentResolver().query(imageUri, null, null, null, null)) {
                    if (cursor != null && cursor.moveToFirst()) {
                        int idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                        if (idx != -1) fileName = cursor.getString(idx);
                    }
                } catch (Exception e) {
                    Log.w(TAG, "Failed to read display name: " + e.getMessage());
                }

                String mimeType = getContentResolver().getType(imageUri);
                if (mimeType == null) mimeType = "image/jpeg";

                String boundary = "----WebKitFormBoundary" + System.currentTimeMillis();
                String urlStr = getBaseUrl() + "/analyze?t=" + System.currentTimeMillis();
                URL url = new URL(urlStr);
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setConnectTimeout(30000);
                conn.setReadTimeout(60000);
                conn.setDoOutput(true);

                conn.setUseCaches(false);
                conn.setRequestProperty("Cache-Control", "no-cache, no-store, must-revalidate");
                conn.setRequestProperty("Pragma", "no-cache");
                conn.setRequestProperty("Expires", "0");

                conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
                conn.setRequestProperty("Connection", "Keep-Alive");
                conn.setRequestProperty("Accept", "application/json");

                dos = new DataOutputStream(conn.getOutputStream());
                dos.writeBytes("--" + boundary + "\r\n");
                dos.writeBytes("Content-Disposition: form-data; name=\"image\"; filename=\"" + fileName + "\"\r\n");
                dos.writeBytes("Content-Type: " + mimeType + "\r\n\r\n");
                dos.write(fileBytes);
                dos.writeBytes("\r\n--" + boundary + "--\r\n");
                dos.flush();

                int responseCode = conn.getResponseCode();
                Log.d(TAG, "/analyze response code: " + responseCode);

                InputStream responseStream = (responseCode >= 400) ? conn.getErrorStream() : conn.getInputStream();
                if (responseStream == null) {
                    Log.e(TAG, "No response stream from server (null)");
                    return "{\"error\":\"No response from server (null)\"}";
                }

                BufferedReader br = new BufferedReader(new InputStreamReader(responseStream, StandardCharsets.UTF_8));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) sb.append(line);
                br.close();
                String responseText = sb.toString();
                Log.d(TAG, "/analyze response body: " + (responseText.length() > 800 ? responseText.substring(0,800) + "..." : responseText));
                return responseText;
            } catch (Exception e) {
                Log.e(TAG, "AnalyzeTask failed: " + e.getMessage(), e);
                return "{\"error\":\"" + e.getMessage().replace("\"","'") + "\"}";
            } finally {
                try { if (dos != null) dos.close(); } catch (Exception ignored) {}
                if (conn != null) conn.disconnect();
            }
        }

        @Override
        protected void onPostExecute(String result) {
            try {
                JSONObject json = new JSONObject(result);
                if (json.has("error")) {
                    String err = json.optString("error");
                    String dbg = json.optString("debug", "");
                    Log.e(TAG, "/analyze reported error: " + err + " debug: " + dbg);
                    tvSummary.setText("Detection failed: " + err + (dbg.isEmpty() ? "" : "\nDebug: " + dbg));
                    Toast.makeText(AiImageAnalysisActivity.this, "Detection failed: " + err, Toast.LENGTH_LONG).show();
                    return;
                }
                if (json.has("result")) {
                    // store the latest analysis result
                    lastAnalysisResult = json;
                    JSONObject resultObj = json.getJSONObject("result");
                    JSONArray wbcArray = resultObj.getJSONArray("wbc_types");

                    StringBuilder summaryText = new StringBuilder("Summary:\n");
                    int total = 0;
                    for (int i = 0; i < wbcArray.length(); i++) {
                        JSONObject cell = wbcArray.getJSONObject(i);
                        String type = cell.getString("type");
                        int count = cell.getInt("count");
                        double percentage = cell.getDouble("percentage");
                        total += count;
                        summaryText.append(type).append(": ").append(count)
                                .append(" (").append(String.format("%.2f", percentage)).append("%)\n");
                    }
                    summaryText.append("Total: ").append(total);
                    tvSummary.setText(summaryText.toString());
                    Log.i(TAG, "Analysis successful. Total count: " + total);
                } else {
                    Log.e(TAG, "Unexpected /analyze response: missing 'result' and no 'error'");
                    tvSummary.setText("Unexpected response from server. Check logs.");
                }
            } catch (Exception e) {
                Log.e(TAG, "Failed to parse /analyze response: " + e.getMessage(), e);
                tvSummary.setText("Parsing error: " + e.getMessage());
                Toast.makeText(AiImageAnalysisActivity.this, "Parsing error: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }
    }

    // SaveAnalysisTask: send JSON to /save_analysis and open report (with logging)
    private class SaveAnalysisTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            HttpURLConnection conn = null;
            try {
                JSONObject json = new JSONObject(params[0]);
                JSONObject resultObj = json.getJSONObject("result");
                JSONArray wbcArray = resultObj.getJSONArray("wbc_types");

                JSONObject payload = new JSONObject();
                payload.put("testing_id", testingId);
                payload.put("email", "test@example.com");
                payload.put("neutrophils", 0);
                payload.put("lymphocytes", 0);
                payload.put("monocytes", 0);
                payload.put("eosinophils", 0);
                payload.put("basophils", 0);

                for (int i = 0; i < wbcArray.length(); i++) {
                    JSONObject cell = wbcArray.getJSONObject(i);
                    String type = cell.getString("type").toLowerCase();
                    int count = cell.getInt("count");
                    payload.put(type, count);
                }

                URL url = new URL(getBaseUrl() + "/save_analysis");
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setConnectTimeout(15000);
                conn.setReadTimeout(30000);
                conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");

                OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream(), StandardCharsets.UTF_8);
                writer.write(payload.toString());
                writer.flush();
                writer.close();

                int responseCode = conn.getResponseCode();
                Log.d(TAG, "/save_analysis response code: " + responseCode);
                InputStream responseStream = (responseCode >= 400) ? conn.getErrorStream() : conn.getInputStream();
                BufferedReader br = new BufferedReader(new InputStreamReader(responseStream, StandardCharsets.UTF_8));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) sb.append(line);
                br.close();
                String resp = sb.toString();
                Log.d(TAG, "/save_analysis body: " + resp);
                return resp;
            } catch (Exception e) {
                Log.e(TAG, "SaveAnalysisTask error", e);
                return "{\"error\":\"" + e.getMessage().replace("\"","'") + "\"}";
            } finally {
                if (conn != null) conn.disconnect();
            }
        }

        @Override
        protected void onPostExecute(String result) {
            try {
                JSONObject json = new JSONObject(result);
                if (json.has("error")) {
                    String err = json.optString("error");
                    Log.e(TAG, "/save_analysis returned error: " + err);
                    Toast.makeText(AiImageAnalysisActivity.this, "Save failed: " + err, Toast.LENGTH_LONG).show();
                    return;
                }
                // open report activity with counts
                if (lastAnalysisResult != null) {
                    JSONObject resultObj = lastAnalysisResult.getJSONObject("result");
                    JSONArray wbcArray = resultObj.getJSONArray("wbc_types");

                    Intent intent = new Intent(AiImageAnalysisActivity.this, ClinicalWBCReportActivity.class);
                    intent.putExtra("testingId", testingId);
                    for (int i = 0; i < wbcArray.length(); i++) {
                        JSONObject cell = wbcArray.getJSONObject(i);
                        String type = cell.getString("type").toLowerCase();
                        int count = cell.getInt("count");
                        intent.putExtra(type, count);
                    }
                    startActivity(intent);
                } else {
                    Toast.makeText(AiImageAnalysisActivity.this, "Nothing to show", Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                Log.e(TAG, "onPostExecute save result parse error", e);
                Toast.makeText(AiImageAnalysisActivity.this, "Save result parse error: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }
    }
}