package com.example.bloodcelbuddy;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.UUID;

public class AnalysisActivity extends AppCompatActivity {

    Button btnManual, btnAI, btnGenerateReport;
    Button btnPlusNeutrophils, btnMinusNeutrophils;
    Button btnPlusMonocytes, btnMinusMonocytes;
    Button btnPlusEosinophils, btnMinusEosinophils;
    Button btnPlusBasophils, btnMinusBasophils;
    Button btnPlusLymphocytes, btnMinusLymphocytes;

    TextView tvNeutrophils, tvMonocytes, tvEosinophils, tvBasophils, tvLymphocytes;
    TextView tvSummary, tvTestingId;

    private SQLiteDatabase db;
    private static final String DATABASE_NAME = "BloodCelBuddy.db";
    private static final String TABLE_ANALYSIS = "analysis";
    private static final String TABLE_CREATE =
            "CREATE TABLE IF NOT EXISTS analysis (" +
                    "_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "testing_id TEXT, " +
                    "email TEXT, " +
                    "neutrophils INTEGER, " +
                    "monocytes INTEGER, " +
                    "eosinophils INTEGER, " +
                    "basophils INTEGER, " +
                    "lymphocytes INTEGER, " +
                    "timestamp DATETIME DEFAULT CURRENT_TIMESTAMP);";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_analysis);

        // Initialize SQLite Database
        try {
            db = openOrCreateDatabase(DATABASE_NAME, MODE_PRIVATE, null);
            db.execSQL(TABLE_CREATE);
        } catch (Exception e) {
            Toast.makeText(this, "Database error: " + e.getMessage(), Toast.LENGTH_LONG).show();
            return;
        }

        // Bind views
        btnManual = findViewById(R.id.btnManual);
        btnAI = findViewById(R.id.btnAI);
        btnGenerateReport = findViewById(R.id.btnGenerateReport);

        btnPlusNeutrophils = findViewById(R.id.btnPlusNeutrophils);
        btnMinusNeutrophils = findViewById(R.id.btnMinusNeutrophils);
        tvNeutrophils = findViewById(R.id.tvNeutrophils);

        btnPlusMonocytes = findViewById(R.id.btnPlusMonocytes);
        btnMinusMonocytes = findViewById(R.id.btnMinusMonocytes);
        tvMonocytes = findViewById(R.id.tvMonocytes);

        btnPlusEosinophils = findViewById(R.id.btnPlusEosinophils);
        btnMinusEosinophils = findViewById(R.id.btnMinusEosinophils);
        tvEosinophils = findViewById(R.id.tvEosinophils);

        btnPlusBasophils = findViewById(R.id.btnPlusBasophils);
        btnMinusBasophils = findViewById(R.id.btnMinusBasophils);
        tvBasophils = findViewById(R.id.tvBasophils);

        btnPlusLymphocytes = findViewById(R.id.btnPlusLymphocytes);
        btnMinusLymphocytes = findViewById(R.id.btnMinusLymphocytes);
        tvLymphocytes = findViewById(R.id.tvLymphocytes);

        tvSummary = findViewById(R.id.tvSummary);
        tvTestingId = findViewById(R.id.tvTestingId);

        // Initialize TextViews with default values
        tvNeutrophils.setText("0");
        tvMonocytes.setText("0");
        tvEosinophils.setText("0");
        tvBasophils.setText("0");
        tvLymphocytes.setText("0");

        // Generate unique Testing ID
        final String finalTestingId = "TID-" + UUID.randomUUID().toString().substring(0, 8);
        tvTestingId.setText("Testing ID: " + finalTestingId);

        // Retrieve email from Intent
        String email = getIntent().getStringExtra("EMAIL");
        final String finalEmail = (email != null && !email.isEmpty()) ? email : "anonymous@example.com";

        // Setup counters
        setupCounter(btnPlusNeutrophils, btnMinusNeutrophils, tvNeutrophils);
        setupCounter(btnPlusMonocytes, btnMinusMonocytes, tvMonocytes);
        setupCounter(btnPlusEosinophils, btnMinusEosinophils, tvEosinophils);
        setupCounter(btnPlusBasophils, btnMinusBasophils, tvBasophils);
        setupCounter(btnPlusLymphocytes, btnMinusLymphocytes, tvLymphocytes);

        btnManual.setOnClickListener(v ->
                Toast.makeText(this, "Manual counter ready", Toast.LENGTH_SHORT).show()
        );

        btnAI.setOnClickListener(v -> {
            Intent intent = new Intent(AnalysisActivity.this, AiImageAnalysisActivity.class);
            intent.putExtra("EMAIL", finalEmail); // Pass email to AiImageAnalysisActivity
            startActivity(intent);
        });

        btnGenerateReport.setOnClickListener(v -> {
            try {
                // Get cell counts
                int neutrophils = Integer.parseInt(tvNeutrophils.getText().toString());
                int monocytes = Integer.parseInt(tvMonocytes.getText().toString());
                int eosinophils = Integer.parseInt(tvEosinophils.getText().toString());
                int basophils = Integer.parseInt(tvBasophils.getText().toString());
                int lymphocytes = Integer.parseInt(tvLymphocytes.getText().toString());

                // Validate cell counts
                if (neutrophils < 0 || monocytes < 0 || eosinophils < 0 || basophils < 0 || lymphocytes < 0) {
                    Toast.makeText(this, "Cell counts cannot be negative", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Save to local SQLite database
                ContentValues values = new ContentValues();
                values.put("testing_id", finalTestingId);
                values.put("email", finalEmail);
                values.put("neutrophils", neutrophils);
                values.put("monocytes", monocytes);
                values.put("eosinophils", eosinophils);
                values.put("basophils", basophils);
                values.put("lymphocytes", lymphocytes);

                long result = db.insert(TABLE_ANALYSIS, null, values);

                if (result != -1) {
                    Toast.makeText(this, "Analysis saved locally", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Failed to save analysis locally", Toast.LENGTH_SHORT).show();
                }

                // Sync with Flask backend
                saveAnalysisToBackend(finalTestingId, finalEmail, neutrophils, monocytes, eosinophils, basophils, lymphocytes);

                // Pass data via Intent to report page
                Intent intent = new Intent(AnalysisActivity.this, ClinicalWBCReportActivity.class);
                intent.putExtra("testingId", finalTestingId);
                intent.putExtra("EMAIL", finalEmail); // Pass email to ClinicalWBCReportActivity (consistent key)
                intent.putExtra("neutrophils", neutrophils);
                intent.putExtra("monocytes", monocytes);
                intent.putExtra("eosinophils", eosinophils);
                intent.putExtra("basophils", basophils);
                intent.putExtra("lymphocytes", lymphocytes);
                startActivity(intent);
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Invalid cell count values", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void saveAnalysisToBackend(String testingId, String email, int neutrophils, int monocytes, int eosinophils, int basophils, int lymphocytes) {
        new Thread(() -> {
            try {
                URL url = new URL("http://10.158.31.61:5000/save_analysis");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json; utf-8");
                conn.setDoOutput(true);

                String jsonInput = "{\"testing_id\":\"" + testingId + "\",\"email\":\"" + email + "\"," +
                        "\"neutrophils\":" + neutrophils + ",\"monocytes\":" + monocytes + "," +
                        "\"eosinophils\":" + eosinophils + ",\"basophils\":" + basophils + "," +
                        "\"lymphocytes\":" + lymphocytes + "}";
                try (OutputStream os = conn.getOutputStream()) {
                    byte[] input = jsonInput.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }

                int responseCode = conn.getResponseCode();
                BufferedReader br = new BufferedReader(new InputStreamReader(
                        responseCode == HttpURLConnection.HTTP_OK ? conn.getInputStream() : conn.getErrorStream(), "utf-8"));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) {
                    response.append(line.trim());
                }

                runOnUiThread(() -> {
                    if (responseCode == HttpURLConnection.HTTP_OK && response.toString().contains("successfully")) {
                        Toast.makeText(this, "Analysis synced with backend", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "Failed to sync analysis: " + response, Toast.LENGTH_LONG).show();
                    }
                });

            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(() ->
                        Toast.makeText(this, "Backend error: " + e.getMessage(), Toast.LENGTH_LONG).show()
                );
            }
        }).start();
    }

    private void setupCounter(Button plus, Button minus, TextView display) {
        plus.setOnClickListener(v -> {
            try {
                int count = Integer.parseInt(display.getText().toString());
                count++;
                display.setText(String.valueOf(count));
                updateSummary();
            } catch (NumberFormatException e) {
                display.setText("0");
                updateSummary();
            }
        });

        minus.setOnClickListener(v -> {
            try {
                int count = Integer.parseInt(display.getText().toString());
                if (count > 0) count--;
                display.setText(String.valueOf(count));
                updateSummary();
            } catch (NumberFormatException e) {
                display.setText("0");
                updateSummary();
            }
        });
    }

    private void updateSummary() {
        try {
            int n = Integer.parseInt(tvNeutrophils.getText().toString());
            int m = Integer.parseInt(tvMonocytes.getText().toString());
            int e = Integer.parseInt(tvEosinophils.getText().toString());
            int b = Integer.parseInt(tvBasophils.getText().toString());
            int l = Integer.parseInt(tvLymphocytes.getText().toString());

            int total = n + m + e + b + l;

            if (total == 0) {
                tvSummary.setText("No cells counted yet.");
                return;
            }

            String summary = "Summary:\n" +
                    "Neutrophils: " + n + " (" + (n * 100 / total) + "%)\n" +
                    "Monocytes: " + m + " (" + (m * 100 / total) + "%)\n" +
                    "Eosinophils: " + e + " (" + (e * 100 / total) + "%)\n" +
                    "Basophils: " + b + " (" + (b * 100 / total) + "%)\n" +
                    "Lymphocytes: " + l + " (" + (l * 100 / total) + "%)\n" +
                    "Total: " + total;

            tvSummary.setText(summary);
        } catch (NumberFormatException e) {
            tvSummary.setText("Error: Invalid cell count values");
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (db != null) {
            db.close();
        }
    }
}