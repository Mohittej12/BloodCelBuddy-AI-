package com.example.bloodcelbuddy;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class AnalysisAdapter extends RecyclerView.Adapter<AnalysisAdapter.ViewHolder> {

    private Context context;
    private List<AnalysisModel> analysisList;

    public AnalysisAdapter(Context context, List<AnalysisModel> analysisList) {
        this.context = context;
        this.analysisList = analysisList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_analysis, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        AnalysisModel model = analysisList.get(position);

        // Show Testing ID in header
        holder.tvTestingId.setText("Testing ID: " + model.getTestingId());

        // Show counts from DB
        holder.tvNeutrophils.setText("Neutrophils: " + model.getNeutrophils());
        holder.tvMonocytes.setText("Monocytes: " + model.getMonocytes());
        holder.tvEosinophils.setText("Eosinophils: " + model.getEosinophils());
        holder.tvBasophils.setText("Basophils: " + model.getBasophils());
        holder.tvLymphocytes.setText("Lymphocytes: " + model.getLymphocytes());
    }

    @Override
    public int getItemCount() {
        return analysisList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvTestingId, tvNeutrophils, tvMonocytes, tvEosinophils, tvBasophils, tvLymphocytes;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTestingId = itemView.findViewById(R.id.tvTestingId);
            tvNeutrophils = itemView.findViewById(R.id.tvNeutrophils);
            tvMonocytes = itemView.findViewById(R.id.tvMonocytes);
            tvEosinophils = itemView.findViewById(R.id.tvEosinophils);
            tvBasophils = itemView.findViewById(R.id.tvBasophils);
            tvLymphocytes = itemView.findViewById(R.id.tvLymphocytes);
        }
    }
}
