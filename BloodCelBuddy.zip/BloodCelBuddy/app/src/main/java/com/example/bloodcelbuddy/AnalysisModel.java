package com.example.bloodcelbuddy;

public class AnalysisModel {
    private String testingId;
    private String email;
    private int neutrophils;
    private int monocytes;
    private int eosinophils;
    private int basophils;
    private int lymphocytes;
    private String timestamp;

    public AnalysisModel(String testingId, String email,
                         int neutrophils, int monocytes,
                         int eosinophils, int basophils,
                         int lymphocytes, String timestamp) {
        this.testingId = testingId;
        this.email = email;
        this.neutrophils = neutrophils;
        this.monocytes = monocytes;
        this.eosinophils = eosinophils;
        this.basophils = basophils;
        this.lymphocytes = lymphocytes;
        this.timestamp = timestamp;
    }

    public String getTestingId() {
        return testingId;
    }

    public String getEmail() {
        return email;
    }

    public int getNeutrophils() {
        return neutrophils;
    }

    public int getMonocytes() {
        return monocytes;
    }

    public int getEosinophils() {
        return eosinophils;
    }

    public int getBasophils() {
        return basophils;
    }

    public int getLymphocytes() {
        return lymphocytes;
    }

    public String getTimestamp() {
        return timestamp;
    }
}
