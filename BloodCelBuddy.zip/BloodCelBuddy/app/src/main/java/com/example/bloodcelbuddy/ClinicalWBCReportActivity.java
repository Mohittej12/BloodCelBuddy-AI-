package com.example.bloodcelbuddy;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ClinicalWBCReportActivity extends AppCompatActivity {

    TextView tvTitle, tvTestingReport, tvInterpretation, tvFooter;
    Button btnDownload;
    TableLayout tableLayout;

    View preloader, mainContent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clinical_wbc_report);

        // Preloader + Main Content
        preloader = findViewById(R.id.preloader);
        mainContent = findViewById(R.id.mainContent);

        // Initially show loader
        mainContent.setVisibility(View.GONE);
        preloader.setVisibility(View.VISIBLE);

        // Hide loader after 2s
        new Handler().postDelayed(() -> {
            preloader.setVisibility(View.GONE);
            mainContent.setVisibility(View.VISIBLE);
        }, 2000);

        // Bind Views
        tvTitle = findViewById(R.id.tvTitle);
        tvTestingReport = findViewById(R.id.tvTestingReport);
        tvInterpretation = findViewById(R.id.tvInterpretation);
        tvFooter = findViewById(R.id.tvFooter);
        btnDownload = findViewById(R.id.btnDownload);
        tableLayout = findViewById(R.id.tableLayout);

        // Get Data from Intent
        String testingId = getIntent().getStringExtra("testingId");
        int neutrophils = getIntent().getIntExtra("neutrophils", 0);
        int monocytes = getIntent().getIntExtra("monocytes", 0);
        int eosinophils = getIntent().getIntExtra("eosinophils", 0);
        int basophils = getIntent().getIntExtra("basophils", 0);
        int lymphocytes = getIntent().getIntExtra("lymphocytes", 0);

        int total = neutrophils + monocytes + eosinophils + basophils + lymphocytes;

        // Dynamic Testing ID
        tvTestingReport.setText("TESTING GENERATION REPORT\nTesting ID: " + testingId);

        // Fill dynamic table
        addRow("Neutrophils", neutrophils, total);
        addRow("Monocytes", monocytes, total);
        addRow("Eosinophils", eosinophils, total);
        addRow("Basophils", basophils, total);
        addRow("Lymphocytes", lymphocytes, total);

        // ✅ Button action: go to DownloadReportActivity
        btnDownload.setOnClickListener(v -> {
            Intent intent = new Intent(ClinicalWBCReportActivity.this, DownloadReportActivity.class);
            intent.putExtra("testingId", testingId);
            intent.putExtra("neutrophils", neutrophils);
            intent.putExtra("monocytes", monocytes);
            intent.putExtra("eosinophils", eosinophils);
            intent.putExtra("basophils", basophils);
            intent.putExtra("lymphocytes", lymphocytes);
            startActivity(intent);
        });
    }

    private void addRow(String cellType, int count, int total) {
        TableRow row = new TableRow(this);

        TextView tvType = new TextView(this);
        tvType.setText(cellType);
        tvType.setPadding(8, 8, 8, 8);

        TextView tvCount = new TextView(this);
        tvCount.setText(String.valueOf(count));
        tvCount.setPadding(8, 8, 8, 8);

        TextView tvPercent = new TextView(this);
        if (total > 0) {
            int percent = (count * 100) / total;
            tvPercent.setText(percent + "%");
        } else {
            tvPercent.setText("0%");
        }
        tvPercent.setPadding(8, 8, 8, 8);

        row.addView(tvType);
        row.addView(tvCount);
        row.addView(tvPercent);

        tableLayout.addView(row);
    }
}
