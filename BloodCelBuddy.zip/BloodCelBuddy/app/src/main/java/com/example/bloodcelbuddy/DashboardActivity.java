package com.example.bloodcelbuddy;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class DashboardActivity extends AppCompatActivity {

    TextView tvWelcome;
    Button btnStartAnalysis;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        // ✅ Preloader logic
        View preloader = findViewById(R.id.preloader);
        View mainContent = findViewById(R.id.mainContent);

        mainContent.setVisibility(View.GONE);
        preloader.setVisibility(View.VISIBLE);

        new Handler().postDelayed(() -> {
            preloader.setVisibility(View.GONE);
            mainContent.setVisibility(View.VISIBLE);
        }, 2000);

        // ✅ Dashboard UI
        tvWelcome = findViewById(R.id.tvWelcome);
        btnStartAnalysis = findViewById(R.id.btnStartAnalysis);

        // Get email from previous activity
        String email = getIntent().getStringExtra("EMAIL");
        if (email != null && !email.isEmpty()) {
            tvWelcome.setText("Welcome back, " + email);
        } else {
            tvWelcome.setText("Welcome back,");
        }

        // Start new analysis
        btnStartAnalysis.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, AnalysisActivity.class);
            if (email != null) intent.putExtra("EMAIL", email);
            startActivity(intent);
        });
    }
}
