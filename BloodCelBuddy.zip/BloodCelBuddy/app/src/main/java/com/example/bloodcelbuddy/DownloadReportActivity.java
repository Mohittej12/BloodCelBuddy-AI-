package com.example.bloodcelbuddy;

import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class DownloadReportActivity extends AppCompatActivity {

    private String testingId, timestamp;
    private int neutrophils, monocytes, eosinophils, basophils, lymphocytes;

    private ProgressBar preloader;
    private LinearLayout mainContent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_download_report);

        // ✅ Preloader + Content Layout
        preloader = findViewById(R.id.preloader);
        mainContent = findViewById(R.id.mainContent);

        // Show preloader first
        mainContent.setVisibility(View.GONE);
        preloader.setVisibility(View.VISIBLE);

        // Delay for 2 seconds before showing content
        new Handler().postDelayed(() -> {
            preloader.setVisibility(View.GONE);
            mainContent.setVisibility(View.VISIBLE);
        }, 2000);

        // ✅ UI elements
        ImageButton backButton = findViewById(R.id.backButton);
        Button downloadButton = findViewById(R.id.downloadButton);
        Button goDashboardButton = findViewById(R.id.btnGoDashboard);

        // ✅ Receive data from ClinicalWBCReportActivity
        testingId = getIntent().getStringExtra("testingId");
        timestamp = getIntent().getStringExtra("timestamp");
        neutrophils = getIntent().getIntExtra("neutrophils", 0);
        monocytes = getIntent().getIntExtra("monocytes", 0);
        eosinophils = getIntent().getIntExtra("eosinophils", 0);
        basophils = getIntent().getIntExtra("basophils", 0);
        lymphocytes = getIntent().getIntExtra("lymphocytes", 0);

        // Back button
        backButton.setOnClickListener(v -> finish());

        // ✅ Generate PDF on click
        downloadButton.setOnClickListener(v -> generatePdf());

        // ✅ Go to Dashboard button
        goDashboardButton.setOnClickListener(v -> {
            Intent intent = new Intent(DownloadReportActivity.this, DashboardActivity.class);
            startActivity(intent);
        });
    }

    private void generatePdf() {
        PdfDocument pdfDoc = new PdfDocument();
        Paint paint = new Paint();

        // Page settings
        PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(595, 842, 1).create();
        PdfDocument.Page page = pdfDoc.startPage(pageInfo);
        Canvas canvas = page.getCanvas();

        // Title
        paint.setTextSize(20);
        paint.setFakeBoldText(true);
        canvas.drawText("Clinical WBC Report", 200, 60, paint);

        paint.setTextSize(14);
        paint.setFakeBoldText(false);

        // Testing Info
        int y = 120;
        canvas.drawText("Testing ID: " + testingId, 50, y, paint);
        y += 30;
        canvas.drawText("Timestamp: " + timestamp, 50, y, paint);
        y += 50;

        // Calculate totals & percentages
        int total = neutrophils + monocytes + eosinophils + basophils + lymphocytes;

        int nPerc = total > 0 ? (neutrophils * 100 / total) : 0;
        int mPerc = total > 0 ? (monocytes * 100 / total) : 0;
        int ePerc = total > 0 ? (eosinophils * 100 / total) : 0;
        int bPerc = total > 0 ? (basophils * 100 / total) : 0;
        int lPerc = total > 0 ? (lymphocytes * 100 / total) : 0;

        // Table-like structure
        paint.setFakeBoldText(true);
        canvas.drawText("Cell Type         Count       Percentage", 50, y, paint);
        paint.setFakeBoldText(false);

        y += 40;
        canvas.drawText("Neutrophils      " + neutrophils + "              " + nPerc + "%", 50, y, paint);
        y += 30;
        canvas.drawText("Monocytes        " + monocytes + "              " + mPerc + "%", 50, y, paint);
        y += 30;
        canvas.drawText("Eosinophils      " + eosinophils + "              " + ePerc + "%", 50, y, paint);
        y += 30;
        canvas.drawText("Basophils        " + basophils + "              " + bPerc + "%", 50, y, paint);
        y += 30;
        canvas.drawText("Lymphocytes      " + lymphocytes + "              " + lPerc + "%", 50, y, paint);

        y += 50;
        paint.setFakeBoldText(true);
        canvas.drawText("Total Cells: " + total, 50, y, paint);

        pdfDoc.finishPage(page);

        // ✅ Save PDF file in Downloads folder
        File pdfFile = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                "WBC_Report_" + testingId + ".pdf");

        try {
            FileOutputStream fos = new FileOutputStream(pdfFile);
            pdfDoc.writeTo(fos);
            pdfDoc.close();

            Toast.makeText(this, "PDF saved in Downloads: " + pdfFile.getName(), Toast.LENGTH_LONG).show();

        } catch (IOException e) {
            Toast.makeText(this, "Error saving PDF: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}
