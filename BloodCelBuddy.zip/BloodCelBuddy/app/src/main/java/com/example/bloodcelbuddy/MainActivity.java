package com.example.bloodcelbuddy;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // links to activity_main.xml

        Button btnEnter = findViewById(R.id.btnEnter);

        btnEnter.setOnClickListener(v -> {
            // Show welcome message
            Toast.makeText(this, "Welcome to Blood Cell Buddy AI!", Toast.LENGTH_SHORT).show();

            // 🔹 Move to next page (SecondActivity)
            Intent intent = new Intent(MainActivity.this, SecondActivity.class);
            startActivity(intent);
        });
    }
}