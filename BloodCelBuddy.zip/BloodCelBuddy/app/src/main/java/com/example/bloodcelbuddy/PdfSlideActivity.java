package com.example.bloodcelbuddy;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

public class PdfSlideActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pdf_slide);

        ImageButton backButton = findViewById(R.id.backButtonPdf);
        Button doneButton = findViewById(R.id.btnDone);

        // Back button goes to previous activity (9th page)
        backButton.setOnClickListener(v -> finish());

        // Done button goes to Dashboard
        doneButton.setOnClickListener(v -> {
            Intent intent = new Intent(PdfSlideActivity.this, DashboardActivity.class);
            startActivity(intent);
        });
    }
}