package com.example.bloodcelbuddy;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class ThirdActivity extends AppCompatActivity {
    private static final String TAG = "ThirdActivity";
    private static final String LOGIN_URL = "http://172.25.57.155:5000/login";

    EditText edtEmail, edtPassword;
    Button btnSignIn, btnCreateAccount, btnUserLogin;
    View preloader, mainContent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);

        // Loader + Main Content
        preloader = findViewById(R.id.preloader);
        mainContent = findViewById(R.id.mainContent);

        // Show loader, hide content initially
        mainContent.setVisibility(View.GONE);
        preloader.setVisibility(View.VISIBLE);

        // Hide loader after 2s
        new Handler().postDelayed(() -> {
            preloader.setVisibility(View.GONE);
            mainContent.setVisibility(View.VISIBLE);
        }, 2000);

        edtEmail = findViewById(R.id.edtEmail);
        edtPassword = findViewById(R.id.edtPassword);
        btnSignIn = findViewById(R.id.btnSignIn);
        btnCreateAccount = findViewById(R.id.btnCreateAccount);
        btnUserLogin = findViewById(R.id.btnUserLogin);

        // Sign In button
        btnSignIn.setOnClickListener(v -> {
            String email = edtEmail.getText().toString().trim();
            String pass = edtPassword.getText().toString().trim();

            if (email.isEmpty() || pass.isEmpty()) {
                Toast.makeText(this, "Please enter Email & Password", Toast.LENGTH_SHORT).show();
            } else {
                loginUser(email, pass);
            }
        });

        // Create account button → go to FourthActivity
        btnCreateAccount.setOnClickListener(v -> {
            Intent intent = new Intent(ThirdActivity.this, FourthActivity.class);
            startActivity(intent);
        });

        btnUserLogin.setOnClickListener(v ->
                Toast.makeText(this, "User Login Selected", Toast.LENGTH_SHORT).show()
        );
    }

    private void loginUser(String email, String password) {
        new Thread(() -> {
            HttpURLConnection conn = null;
            try {
                URL url = new URL(LOGIN_URL);
                conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(10000);
                conn.setReadTimeout(10000);
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json; utf-8");
                conn.setRequestProperty("Accept", "application/json");
                conn.setDoOutput(true);

                // Send request body
                JSONObject body = new JSONObject();
                body.put("email", email);
                body.put("password", password);
                try (OutputStream os = conn.getOutputStream()) {
                    os.write(body.toString().getBytes(StandardCharsets.UTF_8));
                }

                int responseCode = conn.getResponseCode();
                InputStream is = (responseCode == 200) ? conn.getInputStream() : conn.getErrorStream();

                // Read response
                StringBuilder sb = new StringBuilder();
                try (BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = br.readLine()) != null) sb.append(line);
                }

                String responseBody = sb.toString();
                Log.d(TAG, "HTTP " + responseCode + " -> " + responseBody);

                boolean success = false;
                String message = "Login failed";

                if (responseCode == HttpURLConnection.HTTP_OK) {
                    success = true;
                    try {
                        JSONObject respJson = new JSONObject(responseBody);
                        message = respJson.optString("message", "Login successful");
                    } catch (Exception ignore) {
                        message = "Login successful";
                    }
                } else {
                    try {
                        JSONObject respJson = new JSONObject(responseBody);
                        message = respJson.optString("message", message);
                    } catch (Exception ignore) { }
                }

                final boolean finalSuccess = success;
                final String finalMessage = message;

                runOnUiThread(() -> {
                    if (finalSuccess) {
                        Toast.makeText(ThirdActivity.this, finalMessage, Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(ThirdActivity.this, DashboardActivity.class);
                        intent.putExtra("EMAIL", email);
                        startActivity(intent);
                        finish(); // prevent going back to login
                    } else {
                        Toast.makeText(ThirdActivity.this, finalMessage, Toast.LENGTH_LONG).show();
                    }
                });

            } catch (Exception e) {
                Log.e(TAG, "loginUser error", e);
                runOnUiThread(() ->
                        Toast.makeText(ThirdActivity.this, "Network error: " + e.getMessage(), Toast.LENGTH_LONG).show()
                );
            } finally {
                if (conn != null) conn.disconnect();
            }
        }).start();
    }
}
